
package hotel.management.system;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AddDriver extends JFrame implements ActionListener{
    
    JButton add,cancel;
    JTextField tfname , tfage, tfcompany, tfmodel, tflocation;
    JComboBox availablecombo, gendercombo ;
    
     
    
    AddDriver(){
        
        getContentPane().setBackground(Color.white);
        setLayout (null);
        
        JLabel heading = new JLabel("Add Drivers ");
        heading.setFont(new Font("tahoma", Font.ITALIC, 22));
        heading.setBounds(150, 20, 200, 20);
        add(heading);
        
        JLabel lblname = new JLabel("Full Name");
        lblname.setFont(new Font("tahoma", Font.PLAIN, 20));
        lblname.setBounds(60, 80, 120, 30);
        add(lblname);
        
         tfname = new JTextField();
        tfname.setBounds(200, 80, 150, 30);
        add(tfname);
        
        JLabel lblage = new JLabel("Age");
        lblage.setFont(new Font("tahoma", Font.PLAIN, 20));
        lblage.setBounds(60, 130, 120, 30);
        add(lblage);
        
        tfage = new JTextField();
        tfage.setBounds(200, 130, 150, 30);
        add(tfage);
        
        
        
        
        JLabel lblgender = new JLabel("Gender");
        lblgender.setFont(new Font("tahoma", Font.PLAIN, 20));
        lblgender.setBounds(60, 180, 120, 30);
        add(lblgender);
        
        String genderOptions[] = { "Male", "Female" };
         gendercombo = new JComboBox(genderOptions);
        gendercombo.setBounds(200, 180, 150, 30);
        gendercombo.setBackground(Color.white);
        add(gendercombo);
        
        
         JLabel lblCompany = new JLabel("Car Company");
        lblCompany.setFont(new Font("tahoma", Font.PLAIN, 20));
        lblCompany.setBounds(60, 230, 120, 30);
        add(lblCompany);
        
         tfcompany= new JTextField();
        tfcompany.setBounds(200, 230, 150, 30);
        add(tfcompany);
        
        
        JLabel lblmodel = new JLabel("Car Model");
        lblmodel.setFont(new Font("tahoma", Font.PLAIN, 20));
        lblmodel.setBounds(60, 280, 120, 30);
        add(lblmodel);
        
         tfmodel = new JTextField();
        tfmodel.setBounds(200, 280, 150, 30);
        add(tfmodel);
        
        JLabel lblavailable = new JLabel("Available");
        lblavailable.setFont(new Font("tahoma", Font.PLAIN, 20));
        lblavailable.setBounds(60, 330, 120, 30);
        add(lblavailable);
        
        String driverOptions[] = { "Available", "Busy" };
         availablecombo = new JComboBox(driverOptions);
        availablecombo.setBounds(200, 330, 150, 30);
        availablecombo.setBackground(Color.white);
        add(availablecombo);
        
        
        JLabel lbllocation = new JLabel("Location");
        lbllocation.setFont(new Font("tahoma", Font.PLAIN, 20));
        lbllocation.setBounds(60, 380, 120, 30);
        add(lbllocation);
        
        tflocation = new JTextField();
        tflocation.setBounds(200, 380, 150, 30);
        add(tflocation);
        
         add = new JButton("ADD");
        add.setForeground(Color.red);
        add.setBackground(Color.white);
        add.setBounds(60,430,130,30);
        add.addActionListener(this);
        add(add);
        
         cancel = new JButton("CANCEL");
        cancel.setForeground(Color. red);
        cancel.setBackground(Color.white);
        cancel.setBounds(220,430,130,30);
        cancel.addActionListener(this);
        add(cancel);
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/eleven.jpg"));
        Image i2 = i1.getImage().getScaledInstance(500, 300, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(400, 120, 500, 300);
        add(image);
        
        
        
        setBounds(300, 200, 980, 600);
        setVisible(true);
        
        
        
        
        
    }
    
    public void actionPerformed(ActionEvent ae){
        if (ae.getSource() == add){
            
            String name = tfname.getText();
            String age = tfage.getText();
            String gender = (String)gendercombo.getSelectedItem();
            String company = tfcompany.getText();
            String brand = tfmodel.getText();
            String available = (String)availablecombo.getSelectedItem();
            String location = tflocation.getText();
            
            
            if (name.equals("")){
            JOptionPane.showMessageDialog(null, "Name should not be empty");
            return;
            }
            if (location.equals("")){
            JOptionPane.showMessageDialog(null, "Location should not be empty");
            return;
            }
            if (age.equals("")){
            JOptionPane.showMessageDialog(null, "Age should not be empty");
            return;
            }
            if (brand.equals("")){
            JOptionPane.showMessageDialog(null, "Brand should not be empty");
            return;
            
        }
            
            
            
            try {
                Conn conn = new Conn();
                String str = "insert into driver values('"+name+"','"+age+"','"+gender+"','"+company+"','"+brand+"','"+available+"','"+location+"')";
                conn.s.executeUpdate(str);
                
                JOptionPane.showMessageDialog(null, "New Driver Added Successfully");
                setVisible(false);
                
            } catch (Exception e){
                e.printStackTrace();
            }
            
            
            
            
            
        } else {
            setVisible(false);
        }
        
    }
    
    public static void main(String[] args) {
        new AddDriver();
    }
}
