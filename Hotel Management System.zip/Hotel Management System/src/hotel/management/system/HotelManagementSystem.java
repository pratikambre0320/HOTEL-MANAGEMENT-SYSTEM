package hotel.management.system; // file location 

//import java.awt.Color; 
import javax.swing.*; // use to input jframe, swing package is from extended package that why we wright (javax)
import java.awt.*; // is use to input color class 
import java.awt.event.*;


public class HotelManagementSystem extends JFrame implements ActionListener {  //some function are used from this 

    HotelManagementSystem(){  // constuctor 
            
        
        setSize(1200, 565); //this is used to set frame size 
        setLocation(100, 100); //this is used to set the posiston of frame
       
        
        
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/first1.png")); // this is use to add the image to frame
        JLabel image = new JLabel (i1);
        add(image); // is used to add image on frame
        
        JLabel text = new JLabel("HOTEL MANAGEMENT SYSTEM"); // to add text 
        text.setBounds(50, 430, 1000, 90); // setBounds is used to set the size and position of text, just like setSize and setLocation
        text.setForeground(Color.white); // is used to set color  
        text.setFont(new Font ("serif", Font.ROMAN_BASELINE,30)); // is used to set font and size of text 
        image.add(text); // used to show text over image 
        
        
         JButton next = new JButton("Next"); //is used to add button
         next.setBounds(1050, 450, 120, 40); // setBounds is used to set the size and position of button
         next.setBackground(Color.white); //is used to set color of button
         next.setForeground(Color.black);  // is used to set color of text
         next.addActionListener(this);
         next.setFont(new Font ("serif", Font.ROMAN_BASELINE,30)); // is used to set size of text and font
         image.add(next); // is used to show button over image
         


        
        setVisible(true); // bydefault the visibility is fasle which mean hidden, so by this the image is visible
    }
    
    
    public void actionPerformed(ActionEvent ae){
        setVisible(false);
        new Login();
    }
    
    public static void main(String[] args) { // main function
        new HotelManagementSystem();  // new object created(the compiler will come here first then perform other things)
    }
    
}
